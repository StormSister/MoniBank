import{c as e,s as r}from"./flowDiagram-HODETNUW.B4c0oR3r.js";import{_ as a}from"./theme.CeaRglzi.js";import"./chunk-5VM5RSS4.CvZ_eWVa.js";import"./chunk-XXDRQBXY.BIUUZCuK.js";import"./chunk-POPQ4Y6H.CdIlOayT.js";import"./chunk-F27PBJKO.D95lDtY7.js";import"./framework.CUmdn2Of.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
